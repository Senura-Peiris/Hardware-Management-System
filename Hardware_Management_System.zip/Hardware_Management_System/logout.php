<?php
session_start();

/* Destroy session */
session_unset();
session_destroy();

/* Prevent browser back */
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: 0");

/* Redirect to index.php (already in root) */
header("Location: index.php");
exit();
