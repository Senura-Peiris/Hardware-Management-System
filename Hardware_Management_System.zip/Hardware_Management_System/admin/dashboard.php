<?php
session_start();
include "../config/db.php";

/* =======================
   PREVENT BACK BUTTON
======================= */
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: 0");

/* =======================
   PROTECT DASHBOARD
======================= */
if (!isset($_SESSION['user'])) {
    header("Location: ../loginregister.php");
    exit();
}

/* =======================
   CURRENT USER
======================= */
$currentUser = $_SESSION['user'];

/* =======================
   LANGUAGE HANDLING
======================= */
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = $_GET['lang'];
}
$currentLang = $_SESSION['lang'] ?? 'en';

/* =======================
   LANGUAGE CONTENT
======================= */
$lang = [
    'en' => [
        'system_name' => 'Hardware Sales Management System',
        'dashboard'   => 'User Dashboard',
        'categories'  => '📂 Manage Item Categories',
        'items'       => '📦 Add Items',
        'sales'       => '💰 Sales',
        'reports'     => '📊 Reports',
        'profile'     => 'My Profile',
        'logout'      => 'Logout',
        'table_no'    => '#',
        'table_category' => 'Category',
        'table_name'  => 'Item Name',
        'table_cost'  => 'Cost Price (Rs)',
        'table_sell'  => 'Selling Price (Rs)',
        'table_qty'   => 'Quantity',
        'table_date'  => 'Added Date',
        'total'       => 'TOTAL',
        'search_placeholder' => 'Search by name...',
        'filter_category' => 'Filter by category',
        'low_stock'  => '⚠️ Low Stock Items',
        'limited_stock' => 'Limited Stock'
    ],
    'si' => [
        'system_name' => 'හාර්ඩ්වෙයාර් විකුණුම් කළමනාකරණ පද්ධතිය',
        'dashboard'   => 'පරිශීලක මෙහෙයුම් පිටුව',
        'categories'  => '📂 අයිතම වර්ග කළමනාකරණය',
        'items'       => '📦 අයිතම එකතු කරන්න',
        'sales'       => '💰 විකුණුම්',
        'reports'     => '📊 වාර්තා',
        'profile'     => 'මගේ පැතිකඩ',
        'logout'      => 'පිටවන්න',
        'table_no'    => '#',
        'table_category' => 'වර්ගය',
        'table_name'  => 'අයිතම නාමය',
        'table_cost'  => 'මිලදී ගැනීමේ මිල (රු)',
        'table_sell'  => 'විකුණුම් මිල (රු)',
        'table_qty'   => 'ප්‍රමාණය',
        'table_date'  => 'එකතු කළ දිනය',
        'total'       => 'මුළු එකතුව',
        'search_placeholder' => 'නම අනුව සොයන්න...',
        'filter_category' => 'වර්ග අනුව පෙරහන් කරන්න',
        'low_stock'  => '⚠️ අඩු ප්‍රමාණ අයිතම',
        'limited_stock' => 'සීමිත ප්‍රමාණ'
    ]
];

$t = $lang[$currentLang];

/* =======================
   FETCH CATEGORIES
======================= */
$categoryRes = $conn->query("SELECT id, name_en, name_si FROM categories");
$categories = [];
while($row = $categoryRes->fetch_assoc()){
    $categories[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $t['dashboard']; ?></title>

<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:Arial,sans-serif;}
body{background:#f0f2f5;min-height:100vh;display:flex;flex-direction:column;}
.navbar{
    background:#343a40;color:#fff;padding:15px 25px;
    display:flex;justify-content:space-between;align-items:center;
}
.nav-left{font-size:1.4rem;font-weight:bold;}
.nav-right{display:flex;align-items:center;gap:20px;}
.lang a{color:#fff;text-decoration:none;margin:0 5px;}
.lang a.active{color:#ffc107;font-weight:bold;text-decoration:underline;}
.profile{position:relative;}
.profile-icon{
    width:42px;height:42px;border-radius:50%;
    background:#0d6efd;color:#fff;
    display:flex;align-items:center;justify-content:center;
    cursor:pointer;font-size:20px;
}
.profile-card{
    position:absolute;top:55px;right:0;width:240px;
    background:#fff;border-radius:12px;
    box-shadow:0 10px 30px rgba(0,0,0,.2);
    display:none;overflow:hidden;
}
.profile-card .header{
    background:#343a40;color:#fff;padding:15px;text-align:center;
}
.profile-card .time{font-size:0.85rem;color:#ddd;margin-top:5px;}
.profile-card a{
    display:block;padding:12px;text-align:center;
    text-decoration:none;font-weight:bold;
}
.profile-btn{background:#28a745;color:#fff;}
.logout-btn{background:#dc3545;color:#fff;}
.profile-card a:hover{opacity:.9;}

.subtitle{text-align:center;margin:25px 0;font-size:1.5rem;font-weight:bold;}

/* Dashboard cards */
.dashboard-container{
    max-width:1000px;margin:20px auto;
    display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
    gap:25px;padding:0 20px;
}
.dashboard-card{
    background:#fff;border-radius:18px;padding:50px 25px;
    min-height:180px;display:flex;align-items:center;justify-content:center;
    font-size:1.25rem;font-weight:600;color:#333;text-decoration:none;
    box-shadow:0 8px 25px rgba(0,0,0,0.12);transition:0.35s;
}
.dashboard-card:hover{
    transform:translateY(-10px) scale(1.05);
    background:#28a745;color:#fff;
}

/* FILTER + TABLE LAYOUT */
.main-content{max-width:1000px;margin:30px auto;display:flex;gap:20px;padding:0 20px;flex-wrap:wrap;}
.filter-panel{
    flex:1;min-width:200px;background:#fff;padding:15px;border-radius:12px;box-shadow:0 4px 15px rgba(0,0,0,.1);
}
.filter-panel h3{margin-bottom:10px;font-size:1.1rem;}
.filter-panel input, .filter-panel select{width:100%;padding:8px;margin-bottom:10px;border-radius:6px;border:1px solid #ccc;}

.items-table{
    flex:3;min-width:300px;width:100%;border-collapse:collapse;background:#fff;
    border-radius:12px;overflow:hidden;box-shadow:0 4px 15px rgba(0,0,0,0.1);
}
.items-table th,.items-table td{padding:12px;text-align:center;}
.items-table th{background:#28a745;color:#fff;}
.items-table tr:nth-child(even){background:#f9f9f9;}
.total-row{background:#343a40 !important;color:#fff;font-weight:bold;}

/* LOW STOCK TABLE */
.low-stock-table{
    width:100%;border-collapse:collapse;background:#fff;margin:20px 0;border-radius:12px;overflow:hidden;box-shadow:0 4px 15px rgba(0,0,0,0.1);
}
.low-stock-table th, .low-stock-table td{padding:10px;text-align:center;}
.low-stock-table th{background:#dc3545;color:#fff;}
.low-stock-table tr:nth-child(even){background:#f9f9f9;}
.low-stock-msg{color:#dc3545;font-weight:bold;margin:10px 0;text-align:center;}

footer{
    margin-top:auto;background:#343a40;color:#fff;
    text-align:center;padding:15px;
}

/* ========================
   MOBILE RESPONSIVE ENHANCEMENTS
======================== */
@media(max-width:768px){
    /* Make navbar items wrap nicely */
    .navbar {
        flex-direction: column;
        align-items: flex-start;
        gap: 10px;
        padding: 10px 15px;
    }

    .nav-left {
        font-size: 1.2rem;
    }

    .nav-right {
        width: 100%;
        justify-content: space-between;
        gap: 10px;
        flex-wrap: wrap;
    }

    .lang {
        order: 1;
    }

    .profile {
        order: 2;
        margin-top: 5px;
    }

    /* Dashboard cards stack vertically */
    .dashboard-container {
        grid-template-columns: 1fr;
        padding: 0 10px;
        gap: 15px;
    }

    .dashboard-card {
        padding: 40px 15px;
        font-size: 1.1rem;
    }

    /* Filter + Table layout */
    .main-content {
        flex-direction: column;
        gap: 20px;
        padding: 0 10px;
    }

    .filter-panel {
        width: 100%;
        order: 2;
    }

    .items-table {
        width: 100%;
        order: 1;
        font-size: 0.85rem;
        overflow-x: auto;
        display: block;
    }

    .items-table th, .items-table td {
        padding: 8px;
    }

    .low-stock-table {
        width: 100%;
        font-size: 0.85rem;
        overflow-x: auto;
        display: block;
    }

    .low-stock-table th, .low-stock-table td {
        padding: 8px;
    }

    /* Footer smaller padding */
    footer {
        padding: 10px;
        font-size: 0.85rem;
    }

    /* Profile card adjustments */
    .profile-card {
        width: 90vw;
        right: 5vw;
    }
}

</style>
</head>

<body>

<div class="navbar">
    <div class="nav-left"><?= $t['system_name']; ?></div>

    <div class="nav-right">
        <div class="lang">
            <a href="?lang=en" class="<?= $currentLang=='en'?'active':'' ?>">English</a> |
            <a href="?lang=si" class="<?= $currentLang=='si'?'active':'' ?>">සිංහල</a>
        </div>

        <div class="profile">
            <div class="profile-icon" onclick="toggleProfile()">👤</div>
            <div class="profile-card" id="profileCard">
                <div class="header">
                    Hi, <?= htmlspecialchars($currentUser); ?>
                    <div class="time" id="clock"></div>
                </div>
                <a href="updateprofile.php" class="profile-btn"><?= $t['profile']; ?></a>
                <a href="../logout.php" class="logout-btn"><?= $t['logout']; ?></a>
            </div>
        </div>
    </div>
</div>

<div class="subtitle"><?= $t['dashboard']; ?></div>

<div class="dashboard-container">
    <a href="categories.php" class="dashboard-card"><?= $t['categories']; ?></a>
    <a href="items.php" class="dashboard-card"><?= $t['items']; ?></a>
    <a href="sales.php" class="dashboard-card"><?= $t['sales']; ?></a>
    <a href="reports.php" class="dashboard-card"><?= $t['reports']; ?></a>
</div>

<?php
// Fetch all items for table
$items = $conn->query("
    SELECT i.*, c.name_en AS cat_en, c.name_si AS cat_si
    FROM items i
    LEFT JOIN categories c ON i.category_id = c.id
    ORDER BY i.added_date DESC
");

$cat_col  = $currentLang == 'si' ? 'cat_si' : 'cat_en';
$item_col = $currentLang == 'si' ? 'name_si' : 'name_en';

$itemsArray = [];
while($row = $items->fetch_assoc()){
    $itemsArray[] = $row;
}

// Fetch low stock items (quantity <= 20)
$lowStockRes = $conn->query("
    SELECT i.*, c.name_en AS cat_en, c.name_si AS cat_si
    FROM items i
    LEFT JOIN categories c ON i.category_id = c.id
    WHERE i.quantity <= 20
    ORDER BY i.quantity ASC
");
$lowStockItems = [];
while($row = $lowStockRes->fetch_assoc()){
    $lowStockItems[] = $row;
}
?>

<div class="main-content">

    <!-- FILTER PANEL -->
    <div class="filter-panel">
        <h3><?= $t['filter_category']; ?></h3>
        <select id="categoryFilter">
            <option value="all">All</option>
            <?php foreach($categories as $cat): 
                $catName = $currentLang=='si'?$cat['name_si']:$cat['name_en'];
            ?>
            <option value="<?= $cat['id']; ?>"><?= $catName; ?></option>
            <?php endforeach; ?>
        </select>

        <h3><?= $t['search_placeholder']; ?></h3>
        <input type="text" id="searchInput" placeholder="<?= $t['search_placeholder']; ?>">
    </div>

    <!-- LOW STOCK ALERT -->
    <?php if(count($lowStockItems) > 0): ?>
        <div class="low-stock-msg"><?= $t['low_stock']; ?></div>
        <table class="low-stock-table">
            <thead>
                <tr>
                    <th><?= $t['table_no']; ?></th>
                    <th><?= $t['table_category']; ?></th>
                    <th><?= $t['table_name']; ?></th>
                    <th><?= $t['table_qty']; ?></th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $count=1; foreach($lowStockItems as $row): ?>
                <tr>
                    <td><?= $count++; ?></td>
                    <td><?= $row[$cat_col]; ?></td>
                    <td><?= $row[$item_col]; ?></td>
                    <td><?= $row['quantity']; ?></td>
                    <td style="color:#dc3545;font-weight:bold;"><?= $t['limited_stock']; ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>

    <!-- ITEMS TABLE -->
    <table class="items-table" id="itemsTable">
        <thead>
            <tr>
                <th><?= $t['table_no']; ?></th>
                <th><?= $t['table_category']; ?></th>
                <th><?= $t['table_name']; ?></th>
                <th><?= $t['table_cost']; ?></th>
                <th><?= $t['table_sell']; ?></th>
                <th><?= $t['table_qty']; ?></th>
                <th><?= $t['table_date']; ?></th>
            </tr>
        </thead>
        <tbody>
            <?php $count=1; foreach($itemsArray as $row): ?>
            <tr data-cat="<?= $row['category_id']; ?>" data-name="<?= strtolower($row[$item_col]); ?>">
                <td><?= $count++; ?></td>
                <td><?= $row[$cat_col] ?? '-'; ?></td>
                <td><?= $row[$item_col]; ?></td>
                <td><?= number_format($row['cost_price'],2); ?></td>
                <td><?= number_format($row['sell_price'],2); ?></td>
                <td><?= $row['quantity']; ?></td>
                <td><?= $row['added_date']; ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

</div>

<footer>
Hardware Sales Management System &copy; <?= date('Y'); ?> | Developed by M&S TechVerse
</footer>

<script>
function toggleProfile(){
    const card=document.getElementById("profileCard");
    card.style.display = card.style.display==="block"?"none":"block";
}
function updateClock(){
    document.getElementById("clock").innerText =
        new Date().toLocaleTimeString();
}
setInterval(updateClock,1000);
updateClock();

// FILTER + SEARCH LOGIC
const categoryFilter = document.getElementById('categoryFilter');
const searchInput = document.getElementById('searchInput');
const tableRows = document.querySelectorAll('#itemsTable tbody tr');

function filterTable(){
    const catVal = categoryFilter.value;
    const searchVal = searchInput.value.toLowerCase();

    tableRows.forEach(row=>{
        const rowCat = row.dataset.cat;
        const rowName = row.dataset.name;
        const matchCat = (catVal==='all' || catVal===rowCat);
        const matchName = rowName.includes(searchVal);
        row.style.display = (matchCat && matchName) ? '' : 'none';
    });
}

categoryFilter.addEventListener('change', filterTable);
searchInput.addEventListener('input', filterTable);
</script>

</body>
</html>
