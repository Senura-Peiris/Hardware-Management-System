<?php
session_start();
include "../config/db.php";

// ======================= PROTECT PAGE =======================
if(!isset($_SESSION['user'])){
    header("Location: ../loginregister.php");
    exit();
}

// ======================= LANGUAGE HANDLING =======================
if(isset($_GET['lang'])){
    $_SESSION['lang'] = $_GET['lang'];
}
$currentLang = $_SESSION['lang'] ?? 'en';

$lang = [
    'en'=>[
        'title'=>'Sell Items',
        'dashboard'=>'Dashboard',
        'select_item'=>'Select Item',
        'quantity'=>'Quantity',
        'sell_btn'=>'Sell Item',
        'update_btn'=>'Update',
        'delete_btn'=>'Delete',
        'download'=>'Download Report',
        'msg_notfound'=>'Item not found!',
        'msg_invalid'=>'Invalid quantity!',
        'msg_stock'=>'Not enough stock!',
        'msg_success'=>'Item sold successfully!',
        'msg_update'=>'Sale updated successfully!',
        'msg_delete'=>'Sale deleted successfully!',
        'table_no'=>'#',
        'table_item'=>'Item Name',
        'table_qty'=>'Qty Sold',
        'table_price'=>'Selling Price',
        'table_cost'=>'Purchase Price',
        'table_total'=>'Total',
        'table_profit'=>'Profit',
        'table_date'=>'Date',
        'table_total_row'=>'TOTAL'
    ],
    'si'=>[
        'title'=>'අයිතම විකිණීම',
        'dashboard'=>'පරිශීලක මෙහෙයුම් පිටුව',
        'select_item'=>'අයිතමය තෝරන්න',
        'quantity'=>'ප්‍රමාණය',
        'sell_btn'=>'අයිතම විකුණන්න',
        'update_btn'=>'යාවත්කාලීන කරන්න',
        'delete_btn'=>'මකන්න',
        'download'=>'වාර්තාව බාගත කරන්න',
        'msg_notfound'=>'අයිතමය සොයාගත නොහැක!',
        'msg_invalid'=>'අවලංගු ප්‍රමාණය!',
        'msg_stock'=>'ගබඩා ප්‍රමාණය ප්‍රමාණවත් නැත!',
        'msg_success'=>'අයිතමය සාර්ථකව විකිණිය!',
        'msg_update'=>'විකුණුම් යාවත්කාලීන කරන ලදි!',
        'msg_delete'=>'විකුණුම් මකා දමන ලදි!',
        'table_no'=>'#',
        'table_item'=>'අයිතම නාමය',
        'table_qty'=>'විකුණාගත් ප්‍රමාණය',
        'table_price'=>'විකුණුම් මිල',
        'table_cost'=>'මිල',
        'table_total'=>'මුලු මුදල',
        'table_profit'=>'ලාභය',
        'table_date'=>'දිනය',
        'table_total_row'=>'මුළු එකතුව'
    ]
];
$t = $lang[$currentLang];
$itemField = $currentLang=='si'?'name_si':'name_en';
$shopName = "Perera Hardware";
$ownerName = "Vishma Tharaka";

// ======================= HANDLE SELL =======================
$msg = "";
if(isset($_POST['sell'])){
    $item_id = (int)$_POST['item'];
    $qty = (int)$_POST['qty'];

    $item = $conn->query("SELECT * FROM items WHERE id=$item_id")->fetch_assoc();
    if(!$item){
        $msg = $t['msg_notfound'];
    } elseif($qty <= 0){
        $msg = $t['msg_invalid'];
    } elseif($qty > $item['quantity']){
        $msg = $t['msg_stock'];
    } else {
        $conn->query("INSERT INTO sales (item_id, quantity, sell_price, sale_date) VALUES ($item_id, $qty, {$item['sell_price']}, NOW())");
        $conn->query("UPDATE items SET quantity = quantity - $qty WHERE id=$item_id");
        $msg = $t['msg_success'];
    }
}

// ======================= HANDLE DELETE =======================
if(isset($_GET['delete'])){
    $sale_id = (int)$_GET['delete'];
    $sale = $conn->query("SELECT * FROM sales WHERE id=$sale_id")->fetch_assoc();
    if($sale){
        $conn->query("UPDATE items SET quantity = quantity + {$sale['quantity']} WHERE id={$sale['item_id']}");
        $conn->query("DELETE FROM sales WHERE id=$sale_id");
        $msg = $t['msg_delete'];
    }
}

// ======================= HANDLE UPDATE =======================
if(isset($_POST['update'])){
    $sale_id = (int)$_POST['sale_id'];
    $new_qty = (int)$_POST['new_qty'];
    $sale = $conn->query("SELECT * FROM sales WHERE id=$sale_id")->fetch_assoc();
    $item = $conn->query("SELECT * FROM items WHERE id={$sale['item_id']}")->fetch_assoc();
    if($new_qty <=0){
        $msg = $t['msg_invalid'];
    } elseif(($new_qty - $sale['quantity']) > $item['quantity']){
        $msg = $t['msg_stock'];
    } else {
        $diff = $new_qty - $sale['quantity'];
        $conn->query("UPDATE sales SET quantity=$new_qty WHERE id=$sale_id");
        $conn->query("UPDATE items SET quantity = quantity - $diff WHERE id={$sale['item_id']}");
        $msg = $t['msg_update'];
    }
}

// ======================= HANDLE DOWNLOAD =======================
if(isset($_GET['download'])){
    require(__DIR__.'/fpdf/fpdf.php');
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial','B',16);
    $pdf->Cell(0,10,'Sales Report',0,1,'C');
    $pdf->Ln(5);
    $pdf->SetFont('Arial','',12);
    $pdf->Cell(0,8,"Shop: $shopName",0,1);
    $pdf->Cell(0,8,"Owner: $ownerName",0,1);
    $pdf->Cell(0,8,"Date: ".date('Y-m-d'),0,1);
    $pdf->Ln(5);

    $pdf->SetFont('Arial','B',12);
    $pdf->SetFillColor(25,135,84);
    $pdf->SetTextColor(255,255,255);
    $pdf->Cell(50,10,$t['table_item'],1,0,'C',true);
    $pdf->Cell(20,10,$t['table_qty'],1,0,'C',true);
    $pdf->Cell(25,10,$t['table_price'],1,0,'C',true);
    $pdf->Cell(25,10,$t['table_cost'],1,0,'C',true);
    $pdf->Cell(25,10,$t['table_total'],1,0,'C',true);
    $pdf->Cell(25,10,$t['table_profit'],1,1,'C',true);

    $pdf->SetTextColor(0,0,0);
    $pdf->SetFillColor(240,240,240);
    $pdf->SetFont('Arial','',12);

    $sales = $conn->query("
        SELECT s.*, i.name_en, i.name_si, i.cost_price
        FROM sales s 
        JOIN items i ON s.item_id=i.id
        WHERE DATE(s.sale_date)=CURDATE()
    ");

    $fill = false;
    $totalQty=0;
    $totalCost=0;
    $totalSell=0;
    $totalProfit=0;
    while($row = $sales->fetch_assoc()){
        $total = $row['quantity'] * $row['sell_price'];
        $profit = $total - ($row['quantity'] * $row['cost_price']);
        $pdf->Cell(50,10,$row[$itemField],1,0,'C',$fill);
        $pdf->Cell(20,10,$row['quantity'],1,0,'C',$fill);
        $pdf->Cell(25,10,number_format($row['sell_price'],2),1,0,'C',$fill);
        $pdf->Cell(25,10,number_format($row['cost_price'],2),1,0,'C',$fill);
        $pdf->Cell(25,10,number_format($total,2),1,0,'C',$fill);
        $pdf->Cell(25,10,number_format($profit,2),1,1,'C',$fill);
        $fill = !$fill;

        $totalQty += $row['quantity'];
        $totalCost += $row['quantity'] * $row['cost_price'];
        $totalSell += $total;
        $totalProfit += $profit;
    }

    // TOTAL ROW
    $pdf->SetFont('Arial','B',12);
    $pdf->Cell(50,10,$t['table_total_row'],1,0,'C',true);
    $pdf->Cell(20,10,$totalQty,1,0,'C',true);
    $pdf->Cell(25,10,'',1,0,'C',true);
    $pdf->Cell(25,10,number_format($totalCost,2),1,0,'C',true);
    $pdf->Cell(25,10,number_format($totalSell,2),1,0,'C',true);
    $pdf->Cell(25,10,number_format($totalProfit,2),1,1,'C',true);

    $pdf->Output('D','sales_report_'.date('Y-m-d').'.pdf');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title><?= $t['title']; ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:Arial,sans-serif;}
body{background:#f0f2f5;min-height:100vh;display:flex;flex-direction:column;}
.navbar{background:#343a40;color:#fff;padding:15px 25px;display:flex;justify-content:space-between;align-items:center;}
.nav-left{font-size:1.5rem;font-weight:bold;}
.nav-right{display:flex;gap:15px;align-items:center;}
.nav-btn{background:#0d6efd;color:#fff;padding:8px 14px;border-radius:8px;text-decoration:none;font-weight:bold;}
.lang a{color:#fff;text-decoration:none;}
.lang a.active{color:#ffc107;font-weight:bold;text-decoration:underline;}
.container{max-width:1200px;margin:40px auto;padding:0 20px;flex:1;}
h2{text-align:center;margin-bottom:20px;}
.msg{text-align:center;margin-bottom:15px;font-weight:bold;color:#dc3545;}
form{background:#fff;padding:25px;border-radius:12px;display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:15px;box-shadow:0 4px 15px rgba(0,0,0,0.1);}
form select,form input{padding:10px;border:1px solid #ccc;border-radius:8px;}
form button{background:#28a745;color:#fff;border:none;padding:12px;border-radius:8px;font-size:1rem;cursor:pointer;}
form button:hover{background:#218838;}
table{width:100%;margin-top:30px;border-collapse:collapse;background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 4px 15px rgba(0,0,0,0.1);}
th,td{padding:8px;text-align:center;}
th{background:#28a745;color:#fff;font-size:14px;}
tr:nth-child(even){background:#f9f9f9;}
input[type=number]{width:70px;}
tfoot td{font-weight:bold;background:#fff3cd;}
footer{background:#343a40;color:#fff;text-align:center;padding:15px;margin-top:auto;}
a{color:#dc3545;text-decoration:none;font-weight:bold;}
a:hover{text-decoration:underline;}

/* ========================
   MOBILE RESPONSIVE FIX
======================== */
@media (max-width: 768px){

    /* Navbar */
    .navbar{
        flex-direction: column;
        align-items: flex-start;
        gap: 10px;
        padding: 12px 15px;
    }

    .nav-left{
        font-size: 1.2rem;
    }

    .nav-right{
        width: 100%;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 10px;
    }

    .nav-btn{
        padding: 6px 12px;
        font-size: 0.85rem;
    }

    .lang{
        font-size: 0.85rem;
    }

    /* Container */
    .container{
        margin: 25px auto;
        padding: 0 10px;
    }

    h2{
        font-size: 1.2rem;
    }

    /* Form */
    form{
        grid-template-columns: 1fr;
        padding: 15px;
        gap: 10px;
    }

    form select,
    form input{
        padding: 8px;
        font-size: 0.85rem;
    }

    form button{
        padding: 10px;
        font-size: 0.9rem;
    }

    /* Table */
    table{
        font-size: 0.8rem;
        display: block;
        overflow-x: auto;
        white-space: nowrap;
    }

    th, td{
        padding: 6px;
    }

    input[type=number]{
        width: 55px;
    }

    /* Footer */
    footer{
        font-size: 0.85rem;
        padding: 10px;
    }
}

/* ========================
   EXTRA SMALL DEVICES (iPhone SE)
======================== */
@media (max-width: 375px){

    .nav-left{
        font-size: 1rem;
    }

    .nav-btn{
        font-size: 0.75rem;
        padding: 5px 10px;
    }

    h2{
        font-size: 1.05rem;
    }

    form select,
    form input{
        font-size: 0.75rem;
        padding: 6px;
    }

    form button{
        font-size: 0.8rem;
        padding: 8px;
    }

    table{
        font-size: 0.7rem;
    }

    th, td{
        padding: 5px;
    }

    input[type=number]{
        width: 48px;
    }
}

</style>
</head>
<body>

<div class="navbar">
    <div class="nav-left"><?= $t['title']; ?></div>
    <div class="nav-right">
        <a href="dashboard.php" class="nav-btn">🏠 <?= $t['dashboard']; ?></a>
        <div class="lang">
            <a href="?lang=en" class="<?= ($currentLang=='en')?'active':''; ?>">English</a> |
            <a href="?lang=si" class="<?= ($currentLang=='si')?'active':''; ?>">සිංහල</a>
        </div>
    </div>
</div>

<div class="container">
    <h2><?= $t['title']; ?></h2>
    <?php if($msg): ?><div class="msg"><?= $msg ?></div><?php endif; ?>

    <!-- SELL FORM -->
    <form method="post">
        <select name="item" required>
            <option value=""><?= $t['select_item']; ?></option>
            <?php
            $items = $conn->query("SELECT * FROM items");
            while($i = $items->fetch_assoc()){
                echo "<option value='{$i['id']}'>{$i[$itemField]} (Stock: {$i['quantity']})</option>";
            }
            ?>
        </select>
        <input type="number" name="qty" min="1" placeholder="<?= $t['quantity']; ?>" required>
        <button name="sell"><?= $t['sell_btn']; ?></button>
    </form>

    <!-- DOWNLOAD BUTTON -->
    <a href="?download=1" class="nav-btn" style="margin-top:15px; display:inline-block;"><?= $t['download']; ?></a>

    <!-- SALES TABLE -->
    <table>
        <thead>
        <tr>
            <th><?= $t['table_no']; ?></th>
            <th><?= $t['table_item']; ?></th>
            <th><?= $t['table_qty']; ?></th>
            <th><?= $t['table_price']; ?></th>
            <th><?= $t['table_cost']; ?></th>
            <th><?= $t['table_total']; ?></th>
            <th><?= $t['table_profit']; ?></th>
            <th><?= $t['table_date']; ?></th>
            <th>Actions</th>
        </tr>
        </thead>
        <tbody>
        <?php
        $sales = $conn->query("
            SELECT s.*, i.name_en, i.name_si, i.cost_price
            FROM sales s
            JOIN items i ON s.item_id=i.id
            ORDER BY s.sale_date DESC
        ");
        $no=1;
        $totalQty=0;
        $totalCost=0;
        $totalSell=0;
        $totalProfit=0;
        while($row=$sales->fetch_assoc()):
            $total = $row['quantity'] * $row['sell_price'];
            $profit = $total - ($row['quantity'] * $row['cost_price']);
            $totalQty += $row['quantity'];
            $totalCost += $row['quantity'] * $row['cost_price'];
            $totalSell += $total;
            $totalProfit += $profit;
        ?>
        <tr>
            <td><?= $no++; ?></td>
            <td><?= $row[$itemField]; ?></td>
            <td>
                <form method="post" style="display:inline-block;">
                    <input type="hidden" name="sale_id" value="<?= $row['id']; ?>">
                    <input type="number" name="new_qty" value="<?= $row['quantity']; ?>" min="1">
                    <button type="submit" name="update"><?= $t['update_btn']; ?></button>
                </form>
            </td>
            <td><?= number_format($row['sell_price'],2); ?></td>
            <td><?= number_format($row['cost_price'],2); ?></td>
            <td><?= number_format($total,2); ?></td>
            <td><?= number_format($profit,2); ?></td>
            <td><?= $row['sale_date']; ?></td>
            <td>
                <a href="?delete=<?= $row['id']; ?>" onclick="return confirm('Are you sure?')"><?= $t['delete_btn']; ?></a>
            </td>
        </tr>
        <?php endwhile; ?>
        </tbody>
        <tfoot>
        <tr>
            <td colspan="2"><?= $t['table_total_row']; ?></td>
            <td><?= $totalQty ?></td>
            <td></td>
            <td><?= number_format($totalCost,2) ?></td>
            <td><?= number_format($totalSell,2) ?></td>
            <td><?= number_format($totalProfit,2) ?></td>
            <td colspan="2"></td>
        </tr>
        </tfoot>
    </table>
</div>

<footer>
Hardware Sales Management System © 2026 | Developed by M&S TechVerse
</footer>
</body>
</html>
