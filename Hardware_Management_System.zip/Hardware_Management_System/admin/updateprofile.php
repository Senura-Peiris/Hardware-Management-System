<?php
session_start();
include "../config/db.php";

/* ======================= AUTH CHECK ======================= */
if (!isset($_SESSION['user_id'])) {
    header("Location: ../loginregister.php");
    exit();
}
$user_id = $_SESSION['user_id'];

/* ======================= LANGUAGE HANDLING ======================= */
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = $_GET['lang'];
}
$currentLang = $_SESSION['lang'] ?? 'en';

$langData = [
    'en' => [
        'title' => 'My Profile',
        'username' => 'Username',
        'email' => 'Email',
        'old_password' => 'Old Password',
        'new_password' => 'New Password',
        'confirm_password' => 'Confirm New Password',
        'update' => 'Update Profile',
        'back' => '⬅ Back to Dashboard',
        'success_update' => 'Profile updated successfully!',
        'success_pw' => 'Profile and password updated successfully!',
        'error_old_pw' => 'Old password is incorrect.',
        'error_confirm_pw' => 'New password and confirm password do not match.',
        'error_required_old' => 'Please enter old password to set a new one.',
        'error_update' => 'Error updating profile. Try again.'
    ],
    'si' => [
        'title' => 'මගේ පැතිකඩ',
        'username' => 'පරිශීලක නාමය',
        'email' => 'ඊමේල්',
        'old_password' => 'පැරණි මුරපදය',
        'new_password' => 'නව මුරපදය',
        'confirm_password' => 'නව මුරපදය තහවුරු කරන්න',
        'update' => 'පැතිකඩ යාවත්කාලීන කරන්න',
        'back' => '⬅ පසුගිය පිටුවට',
        'success_update' => 'පැතිකඩ යාවත්කාලීන කරන ලදී!',
        'success_pw' => 'පැතිකඩ සහ මුරපදය යාවත්කාලීන කරන ලදී!',
        'error_old_pw' => 'පැරණි මුරපදය වැරදියි.',
        'error_confirm_pw' => 'නව මුරපදය සහ තහවුරු මුරපදය එකිනෙකට නොගැලපේ.',
        'error_required_old' => 'නව මුරපදයක් සකස් කිරීමට පැරණි මුරපදය ඇතුළත් කරන්න.',
        'error_update' => 'පැතිකඩ යාවත්කාලීන කිරීමේදී දෝෂයක්. නැවත උත්සාහ කරන්න.'
    ]
];
$lang = $langData[$currentLang];

/* ======================= FETCH USER DATA ======================= */
$result = $conn->query("SELECT username, email, password FROM users WHERE id='$user_id'");
if ($result->num_rows == 0) {
    header("Location: ../loginregister.php");
    exit();
}
$user = $result->fetch_assoc();

$success = $error = "";

/* ======================= UPDATE PROFILE ======================= */
if (isset($_POST['update'])) {
    $username = $conn->real_escape_string($_POST['username']);
    $email = $conn->real_escape_string($_POST['email']);
    $old_pw = $_POST['old_password'];
    $new_pw = $_POST['new_password'];
    $confirm_pw = $_POST['confirm_password'];

    if (!empty($new_pw)) {
        if (empty($old_pw)) {
            $error = $lang['error_required_old'];
        } elseif (!password_verify($old_pw, $user['password'])) {
            $error = $lang['error_old_pw'];
        } elseif ($new_pw !== $confirm_pw) {
            $error = $lang['error_confirm_pw'];
        } else {
            $hashed = password_hash($new_pw, PASSWORD_DEFAULT);
            $update = $conn->query("UPDATE users SET username='$username', email='$email', password='$hashed' WHERE id='$user_id'");
            if ($update) {
                $_SESSION['user'] = $username;
                $success = $lang['success_pw'];
                $result = $conn->query("SELECT username,email,password FROM users WHERE id='$user_id'");
                $user = $result->fetch_assoc();
            } else {
                $error = $lang['error_update'];
            }
        }
    } else {
        // Update username/email only
        $update = $conn->query("UPDATE users SET username='$username', email='$email' WHERE id='$user_id'");
        if ($update) {
            $_SESSION['user'] = $username;
            $success = $lang['success_update'];
            $result = $conn->query("SELECT username,email,password FROM users WHERE id='$user_id'");
            $user = $result->fetch_assoc();
        } else {
            $error = $lang['error_update'];
        }
    }
}
?>

<!DOCTYPE html>
<html lang="<?= $currentLang; ?>">
<head>
<meta charset="UTF-8">
<title><?= $lang['title']; ?></title>
<style>
body{background:#f0f2f5;font-family:Arial,sans-serif;}
.profile-container{max-width:500px;margin:80px auto;background:#fff;padding:30px;border-radius:16px;box-shadow:0 10px 30px rgba(0,0,0,0.15);}
.profile-container h2{text-align:center;margin-bottom:25px;}
.form-group{margin-bottom:15px;}
.form-group label{font-weight:bold;display:block;margin-bottom:6px;}
.form-group input{width:100%;padding:10px;border-radius:8px;border:1px solid #ccc;}
button{width:100%;padding:12px;background:#28a745;color:#fff;border:none;border-radius:10px;font-size:1rem;cursor:pointer;transition:0.3s;}
button:hover{background:#218838;}
.msg-success{background:#d4edda;color:#155724;padding:10px;border-radius:8px;margin-bottom:15px;text-align:center;}
.msg-error{background:#f8d7da;color:#721c24;padding:10px;border-radius:8px;margin-bottom:15px;text-align:center;}
.back{text-align:center;margin-top:15px;}
.back a{text-decoration:none;color:#007bff;}
.top-bar{text-align:right;margin-bottom:15px;}
.top-bar a{text-decoration:none;margin-left:10px;font-weight:bold;color:#343a40;}
.top-bar a.active{text-decoration:underline;color:#007bff;}
</style>
</head>
<body>

<!-- LANGUAGE SWITCH -->
<div class="top-bar">
    <a href="?lang=en" class="<?= $currentLang=='en'?'active':'' ?>">English</a> |
    <a href="?lang=si" class="<?= $currentLang=='si'?'active':'' ?>">සිංහල</a>
</div>

<div class="profile-container">
    <h2>👤 <?= $lang['title']; ?></h2>

    <?php if($success): ?>
        <div class="msg-success"><?= $success ?></div>
    <?php endif; ?>
    <?php if($error): ?>
        <div class="msg-error"><?= $error ?></div>
    <?php endif; ?>

    <form method="post">
        <div class="form-group">
            <label><?= $lang['username']; ?></label>
            <input type="text" name="username" value="<?= htmlspecialchars($user['username']); ?>" required>
        </div>
        <div class="form-group">
            <label><?= $lang['email']; ?></label>
            <input type="email" name="email" value="<?= htmlspecialchars($user['email']); ?>" required>
        </div>
        <div class="form-group">
            <label><?= $lang['old_password']; ?></label>
            <input type="password" name="old_password">
        </div>
        <div class="form-group">
            <label><?= $lang['new_password']; ?></label>
            <input type="password" name="new_password">
        </div>
        <div class="form-group">
            <label><?= $lang['confirm_password']; ?></label>
            <input type="password" name="confirm_password">
        </div>
        <button type="submit" name="update"><?= $lang['update']; ?></button>
    </form>

    <div class="back">
        <a href="dashboard.php"><?= $lang['back']; ?></a>
    </div>
</div>

</body>
</html>
