<?php
session_start();
include "../config/db.php";

/* =======================
   LANGUAGE HANDLING
======================= */
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = $_GET['lang'];
}
$currentLang = $_SESSION['lang'] ?? 'en';

$lang = [
    'en' => [
        'report' => 'Reports',
        'dashboard' => 'Dashboard',
        'items_report' => 'Items Report',
        'item' => 'Item',
        'category' => 'Category',
        'qty' => 'Quantity Sold',
        'buy' => 'Purchase Price',
        'sell' => 'Selling Price',
        'added_date' => 'Added Date',
        'total_purchase' => 'Total Purchase Value',
        'total_sell' => 'Total Selling Value',
        'total_income' => 'Total Income',
        'daily_income' => 'Today\'s Summary',
        'monthly_income' => 'This Month\'s Summary',
        'yearly_income' => 'This Year\'s Summary',
        'summary' => 'Summary',
        'period' => 'Period',
        'items_sold' => 'Items Sold',
        'purchase_cost' => 'Purchase Cost',
        'sell_amount' => 'Sell Amount',
        'profit' => 'Profit'
    ],
    'si' => [
        'report' => 'වාර්තා',
        'dashboard' => 'පරිශීලක මෙහෙයුම් පිටුව',
        'items_report' => 'අයිතම වාර්තාව',
        'item' => 'අයිතමය',
        'category' => 'වර්ගය',
        'qty' => 'විකුණාගත් ප්‍රමාණය',
        'buy' => 'මිලදී ගැනීමේ මිල',
        'sell' => 'විකුණුම් මිල',
        'added_date' => 'එකතු කළ දිනය',
        'total_purchase' => 'මුළු මිලදී ගැනීමේ අගය',
        'total_sell' => 'මුළු විකුණුම් අගය',
        'total_income' => 'මුළු ආදායම',
        'daily_income' => 'අද දිනයේ සාරාංශය',
        'monthly_income' => 'මෙම මාසයේ සාරාංශය',
        'yearly_income' => 'මෙම අවුරුද්දේ සාරාංශය',
        'summary' => 'සාරාංශය',
        'period' => 'කාලය',
        'items_sold' => 'විකුණාගත් අයිතම',
        'purchase_cost' => 'මිලදී ගැනීමේ වියදම',
        'sell_amount' => 'විකුණුම් මුදල',
        'profit' => 'ලාභය'
    ]
];

$t = $lang[$currentLang];
$itemField = ($currentLang == 'si') ? 'name_si' : 'name_en';

$today = date('Y-m-d');
$thisMonth = date('Y-m');
$thisYear = date('Y');
$monthName = date('F', strtotime($thisMonth.'-01'));

// ======================
// SUMMARY TOTALS FROM SALES ONLY
// ======================
function getSummary($conn, $dateCondition) {
    $res = $conn->query("
        SELECT 
            SUM(s.quantity) AS qty,
            SUM(s.quantity * COALESCE(i.cost_price,0)) AS purchase,
            SUM(s.quantity * s.sell_price) AS sell
        FROM sales s
        INNER JOIN items i ON s.item_id = i.id
        WHERE $dateCondition
    ");
    return $res->fetch_assoc();
}

$dailyTotal = getSummary($conn, "DATE(s.sale_date)='$today'");
$monthlyTotal = getSummary($conn, "DATE_FORMAT(s.sale_date,'%Y-%m')='$thisMonth'");
$yearlyTotal = getSummary($conn, "DATE_FORMAT(s.sale_date,'%Y')='$thisYear'");

// ======================
// ITEM REPORT (all items, sold quantities)
$res = $conn->query("
    SELECT i.*, c.name_en AS cen, c.name_si AS csi, 
           COALESCE(SUM(s.quantity),0) AS sold_qty,
           COALESCE(SUM(s.quantity*s.sell_price),0) AS sold_total
    FROM items i
    LEFT JOIN categories c ON i.category_id = c.id
    LEFT JOIN sales s ON i.id = s.item_id
    GROUP BY i.id
    ORDER BY i.id DESC
");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $t['report']; ?></title>

<style>
body{
    font-family:Calibri, Arial, sans-serif;
    background:#f0f2f5;
    margin:0;
    min-height:100vh;
    display:flex;
    flex-direction:column;
}

.navbar{
    background:#343a40;
    color:#fff;
    padding:18px 25px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    flex-wrap:wrap;
}
.nav-left{font-size:1.5rem;font-weight:bold;}
.nav-btn{
    background:#0d6efd;
    color:#fff;
    padding:8px 16px;
    border-radius:8px;
    text-decoration:none;
    font-weight:bold;
    margin-right:10px;
}
.lang a{color:#fff;font-weight:bold;text-decoration:none;margin:0 5px;}
.lang a.active{color:#ffc107;text-decoration:underline;}

.container{
    max-width:1200px;
    margin:40px auto;
    padding:0 20px;
}

h3{
    text-align:center;
    color:#0d6efd;
    margin-bottom:20px;
    font-size:1.8rem;
}

table{
    width:100%;
    border-collapse:collapse;
    background:#fff;
    box-shadow:0 4px 15px rgba(0,0,0,0.1);
    margin-bottom:30px;
}

th, td{
    border:1px solid #dee2e6;
    padding:8px;
    text-align:center;
    font-size:16px;
}

th{
    background:#198754;
    color:#fff;
    font-size:18px;
}

tr:nth-child(even){background:#f8f9fa;}

.total-row td{
    font-weight:bold;
    background:#fff3cd;
}

footer{
    background:#343a40;
    color:#fff;
    text-align:center;
    padding:15px;
    margin-top:auto;
}

@media(max-width:768px){
    table{font-size:12px;}
    th, td{padding:6px;}
}

</style>
</head>
<body>

<div class="navbar">
    <span class="nav-left"><?= $t['report']; ?></span>
    <div>
        <a href="dashboard.php" class="nav-btn">🏠 <?= $t['dashboard']; ?></a>
        <span class="lang">
            <a href="?lang=en" class="<?= $currentLang=='en'?'active':''; ?>">English</a> |
            <a href="?lang=si" class="<?= $currentLang=='si'?'active':''; ?>">සිංහල</a>
        </span>
    </div>
</div>

<div class="container">

<h3><?= $t['summary']; ?></h3>

<!-- SUMMARY TABLE -->
<table>
<tr>
    <th><?= $t['period']; ?></th>
    <th><?= $t['items_sold']; ?></th>
    <th><?= $t['purchase_cost']; ?></th>
    <th><?= $t['sell_amount']; ?></th>
    <th><?= $t['profit']; ?></th>
</tr>
<tr>
    <td><?= $t['daily_income']; ?> (<?= $today ?>)</td>
    <td><?= $dailyTotal['qty'] ?? 0 ?></td>
    <td><?= number_format($dailyTotal['purchase'] ?? 0,2) ?></td>
    <td><?= number_format($dailyTotal['sell'] ?? 0,2) ?></td>
    <td><?= number_format(($dailyTotal['sell'] ?? 0)-($dailyTotal['purchase'] ?? 0),2) ?></td>
</tr>
<tr>
    <td><?= $t['monthly_income']; ?> (<?= $monthName ?> <?= date('Y') ?>)</td>
    <td><?= $monthlyTotal['qty'] ?? 0 ?></td>
    <td><?= number_format($monthlyTotal['purchase'] ?? 0,2) ?></td>
    <td><?= number_format($monthlyTotal['sell'] ?? 0,2) ?></td>
    <td><?= number_format(($monthlyTotal['sell'] ?? 0)-($monthlyTotal['purchase'] ?? 0),2) ?></td>
</tr>
<tr>
    <td><?= $t['yearly_income']; ?> (<?= $thisYear ?>)</td>
    <td><?= $yearlyTotal['qty'] ?? 0 ?></td>
    <td><?= number_format($yearlyTotal['purchase'] ?? 0,2) ?></td>
    <td><?= number_format($yearlyTotal['sell'] ?? 0,2) ?></td>
    <td><?= number_format(($yearlyTotal['sell'] ?? 0)-($yearlyTotal['purchase'] ?? 0),2) ?></td>
</tr>
</table>

<h3><?= $t['items_report']; ?></h3>

<!-- ITEMS TABLE -->
<table>
<tr>
    <th>#</th>
    <th><?= $t['item']; ?></th>
    <th><?= $t['category']; ?></th>
    <th><?= $t['qty']; ?></th>
    <th><?= $t['buy']; ?></th>
    <th><?= $t['sell']; ?></th>
    <th><?= $t['added_date']; ?></th>
</tr>
<?php
$i = 1;
$totalPurchase = 0;
$totalSell = 0;

// Fetch all existing items (current stock) to calculate totals
$itemsAll = $conn->query("SELECT * FROM items");

while($r = $res->fetch_assoc()):
    $purchase = $r['sold_qty'] * $r['cost_price'];
    $sell = $r['sold_total'];
?>
<tr>
    <td><?= $i++; ?></td>
    <td><?= $r[$itemField]; ?></td>
    <td><?= ($currentLang=='si') ? $r['csi'] : $r['cen']; ?></td>
    <td><?= $r['sold_qty']; ?></td>
    <td><?= number_format($r['cost_price'],2); ?></td>
    <td><?= number_format($r['sell_price'],2); ?></td>
    <td><?= $r['added_date']; ?></td>
</tr>
<?php endwhile; ?>

<?php
// TOTALS FOR ALL EXISTING STOCK
$totalPurchase = 0;
$totalSell = 0;
while($item = $itemsAll->fetch_assoc()){
    $totalPurchase += $item['cost_price'] * $item['quantity'];
    $totalSell += $item['sell_price'] * $item['quantity'];
}
$totalIncome = $totalSell - $totalPurchase;
?>
<tr class="total-row">
    <td colspan="6" align="right"><?= $t['total_purchase']; ?></td>
    <td><?= number_format($totalPurchase,2); ?></td>
</tr>
<tr class="total-row">
    <td colspan="6" align="right"><?= $t['total_sell']; ?></td>
    <td><?= number_format($totalSell,2); ?></td>
</tr>
<tr class="total-row">
    <td colspan="6" align="right"><?= $t['total_income']; ?></td>
    <td><?= number_format($totalIncome,2); ?></td>
</tr>

</table>

</div>

<footer>
Hardware Sales Management System © 2026 | Developed by M&S TechVerse
</footer>

</body>
</html>
