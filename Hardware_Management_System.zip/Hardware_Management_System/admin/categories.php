<?php
session_start();
include "../config/db.php";

/* =======================
   LANGUAGE HANDLING
======================= */
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = $_GET['lang'];
}
$currentLang = $_SESSION['lang'] ?? 'en';

$lang = [
    'en' => [
        'title' => 'Manage Item Categories',
        'dashboard' => 'Dashboard',
        'name_en' => 'English Name',
        'name_si' => 'Sinhala Name',
        'save' => 'Save',
        'update' => 'Update',
        'delete' => 'Delete',
        'guide_title' => 'Instructions',
        'guide' => 'Use this section to create item categories in both English and Sinhala. These categories will help you organize hardware items properly and will be used when adding new items to the system.',
        'update_success' => 'Category updated successfully!'
    ],
    'si' => [
        'title' => 'අයිතම වර්ග කළමනාකරණය',
        'dashboard' => 'පරිශීලක මෙහෙයුම් පිටුව',
        'name_en' => 'නම (ඉංග්‍රීසි)',
        'name_si' => 'නම (සිංහල)',
        'save' => 'තහවුරු කිරීම',
        'update' => 'යාවත්කාලීන කරන්න',
        'delete' => 'මකාදමන්න',
        'guide_title' => 'උපදෙස්',
        'guide' => 'මෙම කොටස භාවිතා කරමින් අයිතම වර්ග ඉංග්‍රීසි සහ සිංහල භාෂාවලින් එක් කරන්න.',
        'update_success' => 'වර්ගය සාර්ථකව යාවත්කාලීන කරන ලදී!'
    ]
];

$t = $lang[$currentLang];

/* =======================
   HANDLE ADD / UPDATE / DELETE
======================= */
if (isset($_POST['save'])) {
    $name_en = $conn->real_escape_string($_POST['name_en']);
    $name_si = $conn->real_escape_string($_POST['name_si']);
    $conn->query("INSERT INTO categories (name_en, name_si) VALUES ('$name_en','$name_si')");
}

if (isset($_POST['update'])) {
    $id = (int)$_POST['id'];
    $name_en = $conn->real_escape_string($_POST['name_en']);
    $name_si = $conn->real_escape_string($_POST['name_si']);
    $conn->query("UPDATE categories SET name_en='$name_en', name_si='$name_si' WHERE id=$id");

    header("Location: categories.php?updated=1&id=$id&lang=$currentLang");
    exit();
}

if (isset($_POST['delete'])) {
    $id = (int)$_POST['id'];
    $conn->query("DELETE FROM categories WHERE id=$id");
}

$updatedId = $_GET['id'] ?? null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title><?= $t['title']; ?></title>

<style>
body{
    font-family:Arial,sans-serif;
    background:#f0f2f5;
    margin:0;
    min-height:100vh;
    display:flex;
    flex-direction:column;
}

/* NAVBAR (FIXED LIKE ITEMS PAGE) */
.navbar{
    background:#343a40;
    color:#fff;
    padding:15px 25px;
    display:flex;
    justify-content:space-between;
    align-items:center;
}

.nav-left{
    font-size:1.4rem;
    font-weight:bold;
}

.nav-right{
    display:flex;
    align-items:center;
    gap:20px;
}

.nav-btn{
    background:#0d6efd;
    color:#fff;
    padding:8px 14px;
    border-radius:8px;
    text-decoration:none;
    font-weight:bold;
    transition:0.3s;
}

.nav-btn:hover{
    background:#0b5ed7;
}

.lang a{
    color:#fff;
    text-decoration:none;
    font-weight:bold;
}

.lang a.active{
    color:#ffc107;
    text-decoration:underline;
}

/* POPUP MESSAGE */
.popup{
    position:fixed;
    top:20px;
    right:20px;
    background:#28a745;
    color:#fff;
    padding:15px 25px;
    border-radius:10px;
    font-weight:bold;
    box-shadow:0 4px 15px rgba(0,0,0,0.3);
    z-index:9999;
    animation: slideIn 0.5s ease;
}

@keyframes slideIn{
    from{transform:translateX(100%);opacity:0;}
    to{transform:translateX(0);opacity:1;}
}

/* CONTAINER */
.container{
    flex:1;
    max-width:900px;
    margin:40px auto;
    padding:0 20px;
}

/* GUIDE */
.guide{
    background:#e9f7ef;
    border-left:6px solid #28a745;
    padding:15px;
    border-radius:8px;
    margin-bottom:25px;
}

/* FORM */
form{
    background:#fff;
    padding:20px;
    border-radius:12px;
    margin-bottom:30px;
    display:flex;
    gap:15px;
}

input{
    flex:1;
    padding:10px;
}

button{
    color:#fff;
    border:none;
    padding:10px 30px;
    border-radius:8px;
    cursor:pointer;
    font-weight:bold;
}

.update-btn{background:#0d6efd;}
.update-btn:hover{background:#0b5ed7;}

.delete-btn{background:#dc3545;}
.delete-btn:hover{background:#b02a37;}

table{
    width:100%;
    background:#fff;
    border-collapse:collapse;
    border-radius:12px;
    overflow:hidden;
}

th,td{
    padding:12px;
    text-align:center;
}

th{
    background:#28a745;
    color:#fff;
}

tr.updated{
    background:#fff3cd !important;
    animation: blink 1s ease-in-out 2;
}

@keyframes blink{
    0%{background:#fff3cd;}
    50%{background:#ffe69c;}
    100%{background:#fff3cd;}
}

footer{
    background:#343a40;
    color:#fff;
    text-align:center;
    padding:15px;
}

/* ========================
   MOBILE RESPONSIVE FIX
======================== */
@media (max-width: 768px){

/* ACTION BUTTON FIX */
    td:last-child{
        display: flex;
        flex-direction: column;
        gap: 6px;
        min-width: 110px;
    }

    td:last-child button{
        width: 100%;
        font-size: 0.75rem;
        padding: 6px;
    }

    /* INPUT WIDTH FIX */
    td input{
        width: 100%;
        font-size: 0.75rem;
        padding: 6px;
    }

    /* Navbar */
    .navbar{
        flex-direction: column;
        align-items: flex-start;
        gap: 10px;
        padding: 12px 15px;
    }

    .nav-left{
        font-size: 1.2rem;
    }

    .nav-right{
        width: 100%;
        flex-wrap: wrap;
        justify-content: space-between;
        gap: 8px;
    }

    .nav-btn{
        font-size: 0.8rem;
        padding: 6px 10px;
    }

    /* Container */
    .container{
        margin: 25px auto;
        padding: 0 10px;
    }

    /* Guide */
    .guide{
        font-size: 0.85rem;
        padding: 12px;
    }

    /* Form */
    form{
        flex-direction: column;
        gap: 10px;
        padding: 15px;
    }

    input{
        padding: 8px;
        font-size: 0.85rem;
    }

    button{
        width: 100%;
        padding: 8px;
        font-size: 0.85rem;
    }

    /* Table */
    table{
        font-size: 0.8rem;
        overflow-x: auto;
        display: block;
    }

    th, td{
        padding: 6px;
        white-space: nowrap;
    }

    /* Popup */
    .popup{
        right: 10px;
        left: 10px;
        text-align: center;
        font-size: 0.85rem;
    }

    /* Footer */
    footer{
        font-size: 0.8rem;
        padding: 10px;
    }
}

/* Extra small devices (iPhone SE) */
@media (max-width: 375px){

 td:last-child{
        min-width: 100px;
    }

    td:last-child button{
        font-size: 0.7rem;
        padding: 5px;
    }

    .nav-left{
        font-size: 1rem;
    }

    .guide{
        font-size: 0.8rem;
    }

    table{
        font-size: 0.7rem;
    }

    th, td{
        padding: 4px;
    }
}

</style>
</head>

<body>

<?php if (isset($_GET['updated'])): ?>
<div class="popup" id="popupMsg"><?= $t['update_success']; ?></div>
<script>
setTimeout(() => {
    document.getElementById('popupMsg')?.remove();
}, 2000);
</script>
<?php endif; ?>

<!-- NAVBAR -->
<div class="navbar">
    <div class="nav-left">
        <?= $t['title']; ?>
    </div>

    <div class="nav-right">
        <a href="dashboard.php" class="nav-btn">
            🏠 <?= $t['dashboard']; ?>
        </a>

        <div class="lang">
            <a href="?lang=en" class="<?= $currentLang=='en'?'active':''; ?>">English</a> |
            <a href="?lang=si" class="<?= $currentLang=='si'?'active':''; ?>">සිංහල</a>
        </div>
    </div>
</div>

<div class="container">

<div class="guide">
    <strong><?= $t['guide_title']; ?></strong>
    <p><?= $t['guide']; ?></p>
</div>

<form method="post">
    <input name="name_en" placeholder="<?= $t['name_en']; ?>" required>
    <input name="name_si" placeholder="<?= $t['name_si']; ?>" required>
    <button style="background:#28a745;" name="save"><?= $t['save']; ?></button>
</form>

<table>
<tr>
    <th>#</th>
    <th><?= $t['name_en']; ?></th>
    <th><?= $t['name_si']; ?></th>
    <th>Actions</th>
</tr>

<?php
$i=1;
$result=$conn->query("SELECT * FROM categories ORDER BY id DESC");
while($row=$result->fetch_assoc()):
$isUpdated = ($updatedId == $row['id']) ? 'updated' : '';
?>
<tr class="<?= $isUpdated; ?>">
<td><?= $i++; ?></td>
<form method="post">
<td><input name="name_en" value="<?= htmlspecialchars($row['name_en']); ?>"></td>
<td><input name="name_si" value="<?= htmlspecialchars($row['name_si']); ?>"></td>
<td>
<input type="hidden" name="id" value="<?= $row['id']; ?>">
<button name="update" class="update-btn"><?= $t['update']; ?></button>
<button name="delete" class="delete-btn" onclick="return confirm('Are you sure?');"><?= $t['delete']; ?></button>
</td>
</form>
</tr>
<?php endwhile; ?>
</table>

</div>

<footer>
Hardware Sales Management System © 2026 | Developed by M&S TechVerse
</footer>

</body>
</html>