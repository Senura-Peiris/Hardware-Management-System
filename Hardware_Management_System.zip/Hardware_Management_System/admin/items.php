<?php
session_start();
include "../config/db.php";

/* =======================
   LANGUAGE HANDLING
======================= */
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = $_GET['lang'];
}
$currentLang = $_SESSION['lang'] ?? 'en';

$lang = [
    'en' => [
        'title' => 'Manage and Add Items',
        'dashboard' => 'Dashboard',
        'name_en' => 'Item Name',
        'name_si' => 'Item Name',
        'category' => 'Category',
        'qty' => 'Quantity',
        'buy' => 'Purchase Price',
        'sell' => 'Selling Price',
        'save' => 'Add Item',
        'update' => 'Update',
        'delete' => 'Delete',
        'added_date' => 'Updated Date',
        'add_success' => 'New item added successfully',
        'update_success' => 'Item updated successfully',
        'delete_success' => 'Item deleted successfully'
    ],
    'si' => [
        'title' => 'අයිතම කළමනාකරණය සහ එකතු කිරීම',
        'dashboard' => 'පරිශීලක මෙහෙයුම් පිටුව',
        'name_en' => 'අයිතම නාමය',
        'name_si' => 'අයිතම නාමය',
        'category' => 'වර්ගය',
        'qty' => 'ප්‍රමාණය',
        'buy' => 'මිලදී ගැනීමේ මිල',
        'sell' => 'විකුණුම් මිල',
        'save' => 'එකතු කරන්න',
        'update' => 'යාවත්කාලීන',
        'delete' => 'මකන්න',
        'added_date' => 'යාවත්කාලීන දිනය',
        'add_success' => 'නව අයිතමය සාර්ථකව එක් කරන ලදී',
        'update_success' => 'අයිතමය සාර්ථකව යාවත්කාලීන කරන ලදී',
        'delete_success' => 'අයිතමය සාර්ථකව මකා දමන ලදී'
    ]
];

$t = $lang[$currentLang];
$itemField = ($currentLang == 'si') ? 'name_si' : 'name_en';

$popupMsg = '';
$highlightId = null;

/* =======================
   ADD ITEM
======================= */
if (isset($_POST['save'])) {
    $stmt = $conn->prepare(
        "INSERT INTO items (category_id, name_en, name_si, cost_price, sell_price, quantity, added_date)
         VALUES (?,?,?,?,?,?,NOW())"
    );
    $stmt->bind_param(
        "issddi",
        $_POST['category_id'],
        $_POST['name_en'],
        $_POST['name_si'],
        $_POST['buy'],
        $_POST['sell'],
        $_POST['qty']
    );
    $stmt->execute();
    $popupMsg = $t['add_success'];
}

/* =======================
   UPDATE ITEM
======================= */
if (isset($_POST['update'])) {

    $qty  = trim($_POST['qty']);
    $buy  = trim($_POST['buy']);
    $sell = trim($_POST['sell']);

    if ($qty === '' && $buy === '' && $sell === '') {

        $stmt = $conn->prepare(
            "UPDATE items 
             SET category_id=?, name_en=?, name_si=?,
                 cost_price=NULL, sell_price=NULL, quantity=NULL,
                 added_date=NULL
             WHERE id=?"
        );

        $stmt->bind_param(
            "issi",
            $_POST['category_id'],
            $_POST['name_en'],
            $_POST['name_si'],
            $_POST['id']
        );

    } else {

        $stmt = $conn->prepare(
            "UPDATE items 
             SET category_id=?, name_en=?, name_si=?,
                 cost_price=?, sell_price=?, quantity=?,
                 added_date = NOW()
             WHERE id=?"
        );

        $stmt->bind_param(
            "issddii",
            $_POST['category_id'],
            $_POST['name_en'],
            $_POST['name_si'],
            $buy,
            $sell,
            $qty,
            $_POST['id']
        );
    }

    $stmt->execute();
    $popupMsg = $t['update_success'];
    $highlightId = $_POST['id'];
}

/* =======================
   DELETE ITEM
======================= */
if (isset($_POST['delete'])) {
    $conn->query("DELETE FROM items WHERE id=".(int)$_POST['id']);
    $popupMsg = $t['delete_success'];
}
?>
<!DOCTYPE html>
<html lang="<?= $currentLang; ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="google" content="notranslate">
<title><?= $t['title']; ?></title>

<style>
body{
    font-family:Arial,sans-serif;
    background:#f0f2f5;
    margin:0;
    min-height:100vh;
    display:flex;
    flex-direction:column;
}

/* NAVBAR */
.navbar{
    background:#343a40;
    color:#fff;
    padding:15px 20px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    flex-wrap:wrap;
    gap:10px;
}

.nav-left{
    font-size:1.3rem;
    font-weight:bold;
}

.nav-btn{
    background:#0d6efd;
    color:#fff;
    padding:7px 14px;
    border-radius:8px;
    text-decoration:none;
    font-weight:bold;
    white-space:nowrap;
}

.lang{
    margin-left:15px;
}

.lang a{
    color:#fff;
    font-weight:bold;
    text-decoration:none;
}

.lang a.active{
    color:#ffc107;
    text-decoration:underline;
}

/* POPUP */
.popup{
    position:fixed;
    top:15px;
    left:50%;
    transform:translateX(-50%);
    background:#28a745;
    color:#fff;
    padding:12px 22px;
    border-radius:10px;
    font-weight:bold;
    box-shadow:0 4px 15px rgba(0,0,0,0.3);
    z-index:9999;
}

/* CONTAINER */
.container{
    max-width:1100px;
    margin:30px auto;
    padding:0 15px;
    width:100%;
    box-sizing:border-box;
}

/* FORM */
form{
    background:#fff;
    padding:18px;
    border-radius:12px;
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(200px,1fr));
    gap:12px;
    margin-bottom:15px;
}

input,select{
    padding:9px;
    border-radius:8px;
    border:1px solid #ccc;
    width:100%;
    box-sizing:border-box;
}

button{
    padding:8px;
    border:none;
    border-radius:8px;
    cursor:pointer;
    color:#fff;
    font-weight:bold;
}

.add-btn,.update-btn{background:#0d6efd;}
.delete-btn{background:#dc3545;}

/* TABLE */
.table-wrapper{
    width:100%;
    overflow-x:auto;
    background:#fff;
    border-radius:12px;
}

table{
    width:100%;
    border-collapse:collapse;
    font-size:13px;
    min-width:950px;
}

th,td{
    padding:6px;
    text-align:center;
}

th{
    background:#28a745;
    color:#fff;
}

tr:nth-child(even){background:#f9f9f9;}
tr.highlight{background:#fff3cd !important;}

footer{
    background:#343a40;
    color:#fff;
    text-align:center;
    padding:12px;
    margin-top:auto;
    font-size:0.85rem;
}

/* =========================
   MOBILE FIXES
========================= */
@media (max-width: 768px){

    .navbar{
        flex-direction:row;          /* keep items in one line */
        align-items:center;
    }

    .nav-left{
        font-size:1rem;
        flex:1;                      /* pushes right section */
    }

    .navbar > div{
        display:flex;
        align-items:center;
        gap:8px;
    }

    .nav-btn{
        padding:6px 10px;
        font-size:0.8rem;
    }

    .lang{
        margin-left:auto;            /* 🔥 pushes language to right */
        font-size:0.85rem;
        white-space:nowrap;
    }

    .lang a{
        font-size:0.85rem;
    }
}

/* EXTRA SMALL */
@media (max-width: 400px){

    .nav-btn{
        padding:5px 10px;
        font-size:0.7rem;
    }

    .lang{
        font-size:0.75rem;
    }

    table{
        font-size:0.7rem;
    }
}
</style>

</head>

<body>

<?php if($popupMsg): ?>
<div class="popup" id="popup"><?= $popupMsg; ?></div>
<script>
setTimeout(()=>document.getElementById('popup')?.remove(),2000);
</script>
<?php endif; ?>

<div class="navbar">
    <span class="nav-left"><?= $t['title']; ?></span>
    <div>
        <a href="dashboard.php" class="nav-btn">🏠 <?= $t['dashboard']; ?></a>
        <span class="lang">
            <a href="?lang=en" class="<?= $currentLang=='en'?'active':''; ?>">English</a> |
            <a href="?lang=si" class="<?= $currentLang=='si'?'active':''; ?>">සිංහල</a>
        </span>
    </div>
</div>

<div class="container">

<form method="post">
    <input name="name_en" placeholder="Item Name (English)" required>
    <input name="name_si" placeholder="අයිතම නාමය (සිංහල)" required>
    <select name="category_id" required>
        <option value=""><?= $t['category']; ?></option>
        <?php
        $cats=$conn->query("SELECT * FROM categories");
        $f=$currentLang=='si'?'name_si':'name_en';
        while($c=$cats->fetch_assoc()){
            echo "<option value='{$c['id']}'>{$c[$f]}</option>";
        }
        ?>
    </select>
    <input type="number" name="qty" placeholder="<?= $t['qty']; ?>" required>
    <input type="number" name="buy" placeholder="<?= $t['buy']; ?>" required>
    <input type="number" name="sell" placeholder="<?= $t['sell']; ?>" required>
    <button class="add-btn" name="save"><?= $t['save']; ?></button>
</form>

<div style="margin-bottom:15px;">
    <input type="text" id="searchInput"
        placeholder="<?= $currentLang=='si'?'අයිතම නාමය අනුව සොයන්න...':'Search by item name...'; ?>">
</div>

<div class="table-wrapper">
<table>
<tr>
<th>#</th>
<th><?= $itemField=='name_si'?$t['name_si']:$t['name_en']; ?></th>
<th><?= $t['category']; ?></th>
<th><?= $t['qty']; ?></th>
<th><?= $t['buy']; ?></th>
<th><?= $t['sell']; ?></th>
<th><?= $t['added_date']; ?></th>
<th>Actions</th>
</tr>

<?php
$i=1;
$res=$conn->query("
SELECT items.*, categories.name_en AS cen, categories.name_si AS csi
FROM items LEFT JOIN categories ON items.category_id=categories.id
ORDER BY items.id DESC
");
while($r=$res->fetch_assoc()):
$highlight = ($highlightId == $r['id']) ? 'highlight' : '';
?>
<tr class="<?= $highlight; ?>">
<form method="post">
<td><?= $i++; ?></td>
<td><input name="<?= $itemField; ?>" value="<?= $r[$itemField]; ?>"></td>
<td>
<select name="category_id">
<?php
$cats=$conn->query("SELECT * FROM categories");
while($c=$cats->fetch_assoc()){
    $sel=$c['id']==$r['category_id']?'selected':'';
    $f=$currentLang=='si'?'name_si':'name_en';
    echo "<option value='{$c['id']}' $sel>{$c[$f]}</option>";
}
?>
</select>
</td>
<td><input type="number" name="qty" value="<?= $r['quantity']; ?>"></td>
<td><input type="number" name="buy" value="<?= $r['cost_price']; ?>"></td>
<td><input type="number" name="sell" value="<?= $r['sell_price']; ?>"></td>
<td><?= $r['added_date']; ?></td>
<td>
<input type="hidden" name="id" value="<?= $r['id']; ?>">
<button class="update-btn" name="update"><?= $t['update']; ?></button>
<button class="delete-btn" name="delete" onclick="return confirm('Delete item?')"><?= $t['delete']; ?></button>
</td>
</form>
</tr>
<?php endwhile; ?>
</table>
</div>

</div>

<footer>
Hardware Sales Management System © <?= date('Y'); ?> | Developed by M&S TechVerse
</footer>

<script>
const searchInput = document.getElementById('searchInput');
const tableRows = document.querySelectorAll('table tr');

searchInput.addEventListener('input', function(){
    const searchVal = this.value.toLowerCase();
    tableRows.forEach(row=>{
        const itemName = row.querySelector(`input[name="<?= $itemField; ?>"]`)?.value.toLowerCase();
        if(!itemName || itemName.includes(searchVal)){
            row.style.display='';
        } else {
            row.style.display='none';
        }
    });
});
</script>

</body>
</html>
