<?php
session_start();
include "../config/db.php";

// Absolute path to FPDF library
require(__DIR__ . '/fpdf/fpdf.php');  // Make sure fpdf.php is in admin/fpdf/fpdf.php

// Shop and owner details
$shopName = "Perera Hardware";
$ownerName = "D. Vishma Tharaka Perera";

// Create PDF instance
$pdf = new FPDF();
$pdf->AddPage();

// Title
$pdf->SetFont('Arial','B',16);
$pdf->Cell(0,10,'Daily Report',0,1,'C');
$pdf->Ln(5);

// Shop & owner info
$pdf->SetFont('Arial','',12);
$pdf->Cell(0,8,"Shop: $shopName",0,1);
$pdf->Cell(0,8,"Owner: $ownerName",0,1);
$pdf->Cell(0,8,"Generated on: ".date('Y-m-d H:i:s'),0,1);
$pdf->Ln(5);

// Table header
$pdf->SetFont('Arial','B',12);
$pdf->SetFillColor(25, 135, 84); // green
$pdf->SetTextColor(255,255,255);

$pdf->Cell(25,10,'Date',1,0,'C',true);
$pdf->Cell(20,10,'Time',1,0,'C',true);
$pdf->Cell(40,10,'Shop Name',1,0,'C',true);
$pdf->Cell(40,10,'Owner Name',1,0,'C',true);
$pdf->Cell(30,10,'Qty Sold',1,0,'C',true);
$pdf->Cell(25,10,'Cost',1,0,'C',true);
$pdf->Cell(25,10,'Profit',1,1,'C',true);

// Reset colors for rows
$pdf->SetFillColor(240,240,240);
$pdf->SetTextColor(0,0,0);
$pdf->SetFont('Arial','',12);

// Fetch daily report data
$daily = $conn->query("
    SELECT 
        DATE(added_date) AS report_date,
        TIME(added_date) AS report_time,
        SUM(quantity) AS total_qty,
        SUM(quantity * cost_price) AS daily_cost,
        SUM(quantity * sell_price) - SUM(quantity * cost_price) AS daily_profit
    FROM items
    GROUP BY DATE(added_date)
    ORDER BY report_date DESC
");

$fill = false;
while($row = $daily->fetch_assoc()){
    $pdf->Cell(25,10,$row['report_date'],1,0,'C',$fill);
    $pdf->Cell(20,10,$row['report_time'],1,0,'C',$fill);
    $pdf->Cell(40,10,$shopName,1,0,'C',$fill);
    $pdf->Cell(40,10,$ownerName,1,0,'C',$fill);
    $pdf->Cell(30,10,$row['total_qty'],1,0,'C',$fill);
    $pdf->Cell(25,10,number_format($row['daily_cost'],2),1,0,'C',$fill);
    $pdf->Cell(25,10,number_format($row['daily_profit'],2),1,1,'C',$fill);
    $fill = !$fill;
}

// Output PDF for download
$pdf->Output('D','daily_report_'.date('Y-m-d_H-i-s').'.pdf');
exit();
?>
