<?php
$lang = [
    "title" => "Hardware Management System",
    'system_name' => 'Hardware Sales Management System',
    'dashboard' => 'Dashboard',
];
?>
