<?php
session_start();

/* =======================
   LANGUAGE HANDLING
======================= */
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = $_GET['lang'];
}
$currentLang = $_SESSION['lang'] ?? 'en';

/* =======================
   LANGUAGE CONTENT
======================= */
$langData = [
    'en' => [
        'title' => 'Hardware Management System',
        'start' => 'Start Manage Sales'
    ],
    'si' => [
        'title' => 'හාර්ඩ්වෙයාර් කළමනාකරණ පද්ධතිය',
        'start' => 'විකුණුම් කළමනාකරණය ආරම්භ කරන්න'
    ]
];

$lang = $langData[$currentLang];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $lang['title']; ?></title>

    <style>
        *{
            margin:0;
            padding:0;
            box-sizing:border-box;
            font-family:Arial,sans-serif;
        }

        body{
    background: linear-gradient(
        to right,
        #c2a98c,   /* deeper warm brown */
         #e0d2c1,   /* darker light brown */
        #9c6b4f    /* rich hardware brown */
    );
    color:#333;
    display:flex;
    flex-direction:column;
    min-height:100vh;
}


        /* TOP BAR */
        .top-bar{
            background:#343a40;
            padding:10px 20px;
            text-align:right;
        }

        .top-bar a{
            color:#fff;
            text-decoration:none;
            margin-left:15px;
            font-weight:bold;
        }

        .top-bar a:hover{
            color:#ffc107;
        }

        /* MAIN CONTENT */
        .container{
            flex:1;
            display:flex;
            flex-direction:column;
            justify-content:center;
            align-items:center;
            text-align:center;
            padding:40px 20px;
        }

        h1{
            font-size:2.5rem;
            margin-bottom:40px;
            color:#343a40;
        }

        .btn{
            padding:16px 40px;
            border-radius:10px;
            text-decoration:none;
            font-size:1.2rem;
            font-weight:bold;
            background:#28a745;
            color:#fff;
            transition:0.3s;
        }

        .btn:hover{
            background:#1e7e34;
            transform:scale(1.07);
        }

        /* FOOTER */
        footer{
            background:#343a40;
            color:#fff;
            text-align:center;
            padding:15px 20px;
            font-size:0.9rem;
        }
    </style>
</head>
<body>

<!-- LANGUAGE BAR -->
<div class="top-bar">
    <a href="?lang=en">English</a> |
    <a href="?lang=si">සිංහල</a>
</div>

<!-- MAIN -->
<div class="container">
    <h1><?= $lang['title']; ?></h1>

    <a href="loginregister.php" class="btn">
        <?= $lang['start']; ?>
    </a>
</div>

<!-- FOOTER -->
<footer>
    &copy; <?= date('Y'); ?> Hardware Sales Management System © 2026 | Developed by M&S TechVerse
</footer>

</body>
</html>