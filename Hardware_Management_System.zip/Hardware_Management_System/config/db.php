<?php

$conn = new mysqli("localhost", "root", "", "hardware_system");
if ($conn->connect_error) {
    die("Database Error");
}
?>
