<?php
// Start session ONLY if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* ===============================
   SET / CHANGE LANGUAGE
================================ */

// Allowed languages (security)
$allowedLangs = ['en', 'si'];

// Set default language
if (!isset($_SESSION['lang'])) {
    $_SESSION['lang'] = 'en';
}

// Change language if requested
if (isset($_GET['lang']) && in_array($_GET['lang'], $allowedLangs)) {
    $_SESSION['lang'] = $_GET['lang'];
}

// Current language (used for active state)
$currentLang = $_SESSION['lang'];

/* ===============================
   LOAD LANGUAGE FILE
================================ */

$langFile = __DIR__ . "/../languages/" . $currentLang . ".php";

if (file_exists($langFile)) {
    require_once $langFile;
} else {
    require_once __DIR__ . "/../languages/en.php";
}