<?php
session_start();
include "config/db.php";

$message = "";
$showResetForm = false;

// Step 1: User enters username/email
if(isset($_POST['verify'])){
    $input = trim($_POST['user_input']);
    $query = "SELECT * FROM users WHERE email='$input' OR username='$input'";
    $result = mysqli_query($conn, $query);

    if(mysqli_num_rows($result) > 0){
        $_SESSION['reset_user'] = $input; // store user temporarily
        $showResetForm = true;
    } else {
        $message = "username not found!";
    }
}

// Step 2: User sets new password
if(isset($_POST['reset'])){
    $new_pass = trim($_POST['new_password']);
    $confirm_pass = trim($_POST['confirm_password']);

    if($new_pass !== $confirm_pass){
        $message = "Passwords do not match!";
        $showResetForm = true;
    } else {
        $user = $_SESSION['reset_user'] ?? '';
        if($user){
            $hashed = password_hash($new_pass, PASSWORD_DEFAULT);
            $update = "UPDATE users SET password='$hashed' WHERE email='$user' OR username='$user'";
            mysqli_query($conn, $update);
            unset($_SESSION['reset_user']);
            $message = "Password updated successfully! You can now log in.";
        } else {
            $message = "Session expired. Try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Reset Password</title>
    <style>
        body{font-family: Arial; display:flex; justify-content:center; align-items:center; height:100vh; background:#f0f2f5;}
        .container{background:#fff; padding:30px; width:350px; border-radius:10px; text-align:center;}
        input{width:100%; padding:10px; margin:10px 0; border-radius:5px; border:1px solid #ccc;}
        button{width:100%; padding:10px; background:#dc3545; color:white; border:none; border-radius:5px; cursor:pointer;}
        .msg{color:green; margin-bottom:10px;}
        .error{color:red;}
        a{color:#0d6efd; text-decoration:none;}
    </style>
</head>
<body>

<div class="container">
    <h2>Reset Password</h2>

    <?php if($message): ?>
        <div class="<?= $showResetForm ? 'error' : 'msg' ?>"><?= $message; ?></div>
    <?php endif; ?>

    <?php if($showResetForm): ?>
        <!-- Step 2: Set new password -->
        <form method="POST">
            <input type="password" name="new_password" placeholder="New Password" required>
            <input type="password" name="confirm_password" placeholder="Confirm Password" required>
            <button type="submit" name="reset">Set Password</button>
        </form>
    <?php else: ?>
        <!-- Step 1: Enter username/email -->
        <form method="POST">
            <input type="text" name="user_input" placeholder="Enter Your Username" required>
            <button type="submit" name="verify">Verify</button>
        </form>
    <?php endif; ?>

    <div style="margin-top:10px;">
        <a href="loginregister.php">⬅ Back to Login</a>
    </div>
</div>

</body>
</html>
