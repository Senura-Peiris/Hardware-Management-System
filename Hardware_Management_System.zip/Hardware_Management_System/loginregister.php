<?php
session_start();
include "config/db.php";

/* ================= LANGUAGE HANDLING ================= */
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = $_GET['lang'];
}
$currentLang = $_SESSION['lang'] ?? 'en';

$langData = [
    'en' => [
        'register_title' => 'Create Account',
        'login_title'    => 'Login',
        'username'       => 'Username',
        'email'          => 'Email',
        'password'       => 'Password',
        'register_btn'   => 'Register',
        'login_btn'      => 'Login',
        'have_account'   => 'Have an account?',
        'login_now'      => 'Login now',
        'dont_have'      => "Don't have an account?",
        'create_account' => 'Create account',
        'forgot_pass'    => 'Forgot Password?'
    ],
    'si' => [
        'register_title' => 'ගිණුම සාදන්න',
        'login_title'    => 'පිවිසෙන්න',
        'username'       => 'පරිශීලක නම',
        'email'          => 'ඊමේල්',
        'password'       => 'මුරපදය',
        'register_btn'   => 'ලියාපදිංචි වන්න',
        'login_btn'      => 'පිවිසෙන්න',
        'have_account'   => 'ගිණුමක් තිබේද?',
        'login_now'      => 'පිවිසෙන්න',
        'dont_have'      => "ගිණුමක් නොමැතිද?",
        'create_account' => 'ගිණුමක් සාදන්න',
        'forgot_pass'    => 'මුරපදය අමතකද?'
    ]
];

$t = $langData[$currentLang];

/* ================= REGISTER ================= */
if (isset($_POST['register'])) {
    $username = trim($_POST['username']);
    $email    = trim($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $checkQuery = "SELECT id FROM users WHERE username='$username'";
    $checkResult = mysqli_query($conn, $checkQuery);

    if (mysqli_num_rows($checkResult) > 0) {
        echo "<script>alert('User already exists. Please choose a new one');</script>";
    } else {
        $insertQuery = "INSERT INTO users (username, email, password)
                        VALUES ('$username', '$email', '$password')";
        if (mysqli_query($conn, $insertQuery)) {
            echo "<script>
                    alert('Registration Successful!');
                    window.location.href='loginregister.php?login=true&lang=$currentLang';
                  </script>";
            exit();
        } else {
            echo "<script>alert('Registration failed. Try again');</script>";
        }
    }
}

/* ================= LOGIN ================= */
if (isset($_POST['login'])) {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    $query  = "SELECT * FROM users WHERE username='$username'";
    $result = mysqli_query($conn, $query);
    $user   = mysqli_fetch_assoc($result);

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user'] = $user['username'];  
        $_SESSION['user_id'] = $user['id'];     
        header("Location: admin/dashboard.php");
        exit();
    } else {
        echo "<script>alert('Invalid username or password');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title><?= $t['login_title']; ?> & <?= $t['register_title']; ?></title>
    <style>
        body{
            font-family: Arial;
            background: linear-gradient(to right, #c2a98c, #e0d2c1, #9c6b4f);
            display:flex;
            justify-content:center;
            align-items:center;
            height:100vh;
            position:relative;
            margin:0;
        }
        .container{
            background:#fff;
            padding:30px;
            width:350px;
            border-radius:10px;
            position:relative;
        }
        h2{text-align:center;}
        input{
            width:100%;
            padding:10px;
            margin:10px 0;
        }
        button{
            width:100%;
            padding:10px;
            background:#2563eb;
            color:white;
            border:none;
            cursor:pointer;
        }
        .link{text-align:center; margin-top:10px;}
        .link a{color:#2563eb; cursor:pointer; text-decoration:none;}
        .form{display:none;}
        .forgot{text-align:right; margin:5px 0 15px 0;}
        .forgot a{font-size:0.9rem; color:#dc3545; text-decoration:none;}
        .forgot a:hover{ text-decoration:underline; }

        /* ===== LANGUAGE SWITCHER TOP RIGHT ===== */
        .lang-switch{
            position:absolute;
            top:10px;
            right:10px;
            background:#000;
            padding:5px 10px;
            border-radius:5px;
        }
        .lang-switch a{
            color:#fff;
            text-decoration:none;
            font-weight:bold;
            margin:0 5px;
            padding:2px 5px;
        }
        .lang-switch a.active{
            background:#fff;
            color:#000;
            border-radius:3px;
        }

        @media(max-width:400px){
            .container{width:90%; padding:20px;}
            .lang-switch{top:5px; right:5px; padding:4px 8px;}
            input, button{padding:8px; font-size:14px;}
        }
    </style>
</head>
<body>

<!-- LANGUAGE SWITCHER -->
<div class="lang-switch">
    <a href="?lang=en" class="<?= $currentLang=='en'?'active':''; ?>">EN</a> |
    <a href="?lang=si" class="<?= $currentLang=='si'?'active':''; ?>">සිංහල</a>
</div>

<div class="container">

    <!-- REGISTER FORM -->
    <form method="POST" id="registerForm" class="form">
        <h2><?= $t['register_title']; ?></h2>
        <input type="text" name="username" placeholder="<?= $t['username']; ?>" required>
        <input type="email" name="email" placeholder="<?= $t['email']; ?>" required>
        <input type="password" name="password" placeholder="<?= $t['password']; ?>" required>
        <button type="submit" name="register"><?= $t['register_btn']; ?></button>
        <div class="link">
            <?= $t['have_account']; ?> <a onclick="showLogin()"><?= $t['login_now']; ?></a>
        </div>
    </form>

    <!-- LOGIN FORM -->
    <form method="POST" id="loginForm" class="form">
        <h2><?= $t['login_title']; ?></h2>
        <input type="text" name="username" placeholder="<?= $t['username']; ?>" required>
        <input type="password" name="password" placeholder="<?= $t['password']; ?>" required>
        <div class="forgot">
            <a href="forgotpassword.php?lang=<?= $currentLang; ?>"><?= $t['forgot_pass']; ?></a>
        </div>
        <button type="submit" name="login"><?= $t['login_btn']; ?></button>
        <div class="link">
            <?= $t['dont_have']; ?> <a onclick="showRegister()"><?= $t['create_account']; ?></a>
        </div>
    </form>

</div>

<script>
const loginForm = document.getElementById("loginForm");
const registerForm = document.getElementById("registerForm");

function showLogin(){
    registerForm.style.display="none";
    loginForm.style.display="block";
}
function showRegister(){
    loginForm.style.display="none";
    registerForm.style.display="block";
}

// Open correct form
<?php
if (isset($_GET['login'])) {
    echo "showLogin();";
} else {
    echo "showRegister();";
}
?>
</script>

</body>
</html>
